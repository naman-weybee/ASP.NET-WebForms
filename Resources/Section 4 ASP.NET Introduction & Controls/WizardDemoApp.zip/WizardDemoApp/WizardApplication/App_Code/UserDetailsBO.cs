﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for UserDetailsBO
/// </summary>
public class UserDetailsBO
{
	public UserDetailsBO()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public string strConnection = ConfigurationManager.ConnectionStrings["WizardDB"].ToString();
    public int InsertUser(UserDeatails user)
    {
        SqlConnection con = new SqlConnection(strConnection);
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;
        
        con.Open();
        cmd.CommandText = "Insert into UserDetails(FirstName,LastName,Gender,Address,State,City,Country,ZipCode,MobileNumber,EmailId,Password,SecurityQuestion,SecurityAnswer,IsActive) values('" + user.FirstName + "','" + user.LastName + "','" + user.Gender + "','" + user.Address + "','" + user.State + "','" + user.City + "','" + user.Country + "'," + user.ZipCode + ",'" + user.MobileNumber + "','" + user.EmailId + "','" + user.Password + "','" + user.SecurityQuestion + "','" + user.SecurityAnswer + "','" + user.IsActive + "')";
        cmd.CommandType = CommandType.Text;
        cmd.ExecuteNonQuery();
        cmd.CommandText = "Select @@Identity";
        int id = Convert.ToInt32(cmd.ExecuteScalar());
        con.Close();
        return id;
    }

    public UserDeatails GetUserById(int PKUserid)
    {
        SqlConnection con = new SqlConnection(strConnection);
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;
        
        con.Open();
        cmd.CommandText = "Select * from UserDetails where PKUserId=" + PKUserid;
        cmd.CommandType = CommandType.Text;
        SqlDataReader dr= cmd.ExecuteReader();
        UserDeatails user = null;
        if (dr.HasRows)
        {
            dr.Read();
            user = new UserDeatails((string)dr["FirstName"], (string)dr["LastName"], (string)dr["Gender"], (string)dr["Address"], (string)dr["State"], (string)dr["City"], (string)dr["Country"], (int)dr["ZipCode"], (string)dr["MobileNumber"], (string)dr["EmailId"], (string)dr["Password"], (string)dr["SecurityQuestion"], (string)dr["SecurityAnswer"], (bool)dr["IsActive"]);
        }
        dr.Close();
        return user;
    }
}