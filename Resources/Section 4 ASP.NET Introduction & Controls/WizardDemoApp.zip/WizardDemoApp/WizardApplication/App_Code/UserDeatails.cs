﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for UserDeatails
/// </summary>
public class UserDeatails
{
	public UserDeatails()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    private string _Validate = "";
    public void Validate()
    {
        if (!string.IsNullOrEmpty(_Validate))
            throw new ApplicationException(_Validate);
    }
    public UserDeatails(string firstName, string LastName, string Gender, string Address, string State, string City, string Country, int ZipCode, string MobileNumber, string EmailId, string Password, string SecurityQuestion, string SecurityAnswer, bool IsActive)
    {
        this.FirstName = firstName;
        this.LastName = LastName;
        this.Gender = Gender;
        this.Address = Address;
        this.State=State;
        this.City=City;
        this.Country=Country;
        this.ZipCode=ZipCode;
        this.EmailId=EmailId;
        this.Password=Password;
        this.MobileNumber = MobileNumber;
        this.SecurityQuestion=SecurityQuestion;
        this.SecurityAnswer=SecurityAnswer;
        this.IsActive = IsActive;
    }

    public string _PKUserId;
    public string FirstName { get; set; }
    public string LastName{get;set;}
    public string Gender { get; set; }
    public string Address { get; set; }
    public string State { get; set; }
    public string City { get; set; }
    public string Country{get;set;}
    public int ZipCode { get; set; }
    public string EmailId { get; set; }
    public string Password { get; set; }
    public string MobileNumber { get; set; }
    public string SecurityQuestion { get; set; }
    public string SecurityAnswer { get; set; }
    public bool IsActive { get; set; }
}