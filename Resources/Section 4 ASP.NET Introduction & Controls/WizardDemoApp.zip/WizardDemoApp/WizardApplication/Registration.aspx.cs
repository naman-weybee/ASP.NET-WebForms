﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Registration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    //This event rises when the Finish button is clicked
    protected void Wizard1_FinishButtonClick(object sender, WizardNavigationEventArgs e)
    {
        if (cbTerms.Checked == true)
        {
            int id = Convert.ToInt32(ViewState["id"]);
            Response.Redirect("~/UserAccount.aspx?id="+id);
        }
        else
        {
            lblMessage.Visible = true;
        }
    }
    string Password = "";

   //Gets all the information from all the Wizard steps and inserts the record in the database.

    protected void Wizard1_ActiveStepChanged(object sender, EventArgs e)
    {
        if (Wizard1.ActiveStep.ID == "wsSecurity")
        {
            Password = txtPassword.Text;
            ViewState["Password"] = Password;
        }
        if (Wizard1.ActiveStep.ID == "wsTerms")
        {


            UserDetailsBO objUserBO = new UserDetailsBO();
            string FirstName = txtFirstName.Text;
            string lastName = txtLastName.Text;
            string Gender = ddlGender.SelectedItem.Text;
            string Address = txtAddress.Text;
            string State = txtState.Text;
            string City = txtCity.Text;
            string Country = txtCountry.Text;
            int ZipCode = Convert.ToInt32(txtZipCode.Text);
            string MobileNumber = txtMobNum.Text;
            string EmailId = txtEmailId.Text;
            Password = ViewState["Password"].ToString();
            string SecurityQue = ddlQue.SelectedItem.Text;
            string SecurityAns = txtSecurityAns.Text;
            bool IsActive = true;
            UserDeatails objUserData = new UserDeatails(FirstName, lastName, Gender, Address, State, City, Country, ZipCode, MobileNumber, EmailId, Password, SecurityQue, SecurityAns, IsActive);
            ViewState["id"] = objUserBO.InsertUser(objUserData);
        }
        
    }
}