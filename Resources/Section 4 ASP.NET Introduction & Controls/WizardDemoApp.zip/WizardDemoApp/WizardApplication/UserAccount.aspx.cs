﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class UserAccount : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        UserDetailsBO objUser=new UserDetailsBO();
        int id=Convert.ToInt32(Request.QueryString["id"]);
        lblName.Text = "Welcome " + objUser.GetUserById(id).FirstName+" "+objUser.GetUserById(id).LastName;
        lbllAddress.Text = objUser.GetUserById(id).Address;
        lblState.Text = objUser.GetUserById(id).State;
        lblCity.Text = objUser.GetUserById(id).City;
        lblCountry.Text = objUser.GetUserById(id).Country;
        lblPHNo.Text = objUser.GetUserById(id).MobileNumber;
    }
}