﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    //List of colors and font family
    List<string> lstColors = new List<string> { "Pink", "Orange", "Aqua", "LightGrey", "Silver", "White" };
    List<string> lstFontFamily = new List<string> { "Arial", "Calibri", "Times New Roman", "Comic Sans MS" };
    protected void Page_Load(object sender, EventArgs e)
    {

    }
   
    public void ChangeFont()
    {
        //if radio button font family is selected then changing font family of body 
        if (rbnFontFamily.Checked == true)
        {
            body.Attributes.Add("style", "font-family:" + ddlFont.SelectedItem.Text);
        }
        else
        {
            //If check box font color is selected then changing the font color of the body 
            if (chkFontColor.Checked == true)
            {
                
                body.Attributes.Add("style", "color:" + ddlFont.SelectedItem.Text);
                
            }
            //If check box backgroung color is selected then changing the background color of the body 
            //if (cbBackColor.Checked == true)
            else
            {
                
                body.Attributes["bgcolor"] = ddlFont.SelectedItem.Text;
                
            }
        }
    }

    //This event raises when the user selects a drop down list value
    protected void ddlFont_SelectedIndexChanged(object sender, EventArgs e)
    {
        ChangeFont();

    }

    
  
    protected void chkBackColor_CheckedChanged(object sender, EventArgs e)
    {
        chkFontColor.Checked = false;
    }
    protected void chkFontColor_CheckedChanged(object sender, EventArgs e)
    {
        chkBackColor.Checked = false;
    }

    //This event raises when the checkbox cbBold is selected to make the text bold
    protected void chkBold_CheckedChanged(object sender, EventArgs e)
    {
        if (chkBold.Checked == true)
        {
            body.Attributes.Add("style", "font-weight:bold");

        }
        else
        {
            body.Attributes.Add("style", "font-weight:normal");
        }
    }

    //This event raises when the user selects the radio button
    protected void rbnColor_CheckedChanged(object sender, EventArgs e)
    {
        //Clearing the drop down list and and pacing text select at 0th index
        ddlFont.Items.Clear();
        ListItem lst = new ListItem("--Select--", "0");
        ddlFont.Items.Add(lst);
        //Binding the drop down list with colors and font-family based on radio buton selection 
        if (rbnColor.Checked == true)
        {
            ddlFont.DataSource = lstColors;
            ddlFont.DataBind();
        }
        else if (rbnFontFamily.Checked == true)
        {
            ddlFont.DataSource = lstFontFamily;
            ddlFont.DataBind();
        }
    }
}