﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Drawing;
using System.IO;
using System.Collections;

public partial class MultiviewCtrl : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            mvUploadImage.Visible = false;
            imgOld.ImageUrl = @"~\FlowerImages\crocus-thumb.jpg";
            imgNew.Visible = false;
            BindDataList();
        }
    }

    //To bind the images to the DataList
    protected void BindDataList()
    {
        //To get the image path
        DirectoryInfo dir = new DirectoryInfo(MapPath("FlowerImages"));
        //Get files from the Directory info path
        FileInfo[] files = dir.GetFiles();
        ArrayList listItems = new ArrayList();
        //Add the items to the arraylist
        foreach (FileInfo info in files)
        {
            listItems.Add(info);
        }
        //Bind all the items to the Datalist
        dlImages.DataSource = listItems;
        dlImages.DataBind();

    }

    //To display the view based on the type selected from the Dropdownlist
    protected void ddlType_SelectedIndexChanged(object sender, EventArgs e)
    {
        mvUploadImage.Visible = true;
       
        if (ddlType.SelectedValue == "Upload Image")
        {
            mvUploadImage.ActiveViewIndex = 0;
        }
        else if (ddlType.SelectedValue == "CompressImage")
        {
            mvUploadImage.ActiveViewIndex = 1;
            imgOld.ImageUrl = @"~\FlowerImages\crocus-thumb.jpg";
            imgNew.Visible = false;
        }
         else
         {
             mvUploadImage.ActiveViewIndex = 2;
         }
    }

   //To save the images to the image path
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        //get the file name of the posted image
        string imgName = fuImage.FileName;
        //sets the image path
        string imgPath = "FlowerImages/" + imgName;
        if (fuImage.HasFile)
        {
            //save it to the Folder
            fuImage.SaveAs(Server.MapPath(imgPath));
            BindDataList();
        }
    }
    public bool ThumbnailCallback()
    {
        return false;
    }
    

    protected void btnCreateThumbnail_Click(object sender, EventArgs e)
    {
        //Provides a callback method for determining when the GetThumbnailImage method should prematurely cancel execution.
        System.Drawing.Image.GetThumbnailImageAbort myCallback = new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback);
        Bitmap myBitmap = new Bitmap(Server.MapPath("FlowerImages") + "/crocus-thumb.jpg");
        int thumbwidth = Convert.ToInt32(txtwidth.Text);
        int thumbheight = Convert.ToInt32(txtHeight.Text);
        //Returns a thumbnail for this Image.
        //The GetThumbnailImage method works well when the requested thumbnail image has a size of about 120 x 120 pixels otherwise there will be a noticable
        //loss in the quality of the thumbnail.
        System.Drawing.Image myThumbnail = myBitmap.GetThumbnailImage(thumbwidth, thumbheight, myCallback, IntPtr.Zero);
        //Save the image to the Images folder below
        myThumbnail.Save(Server.MapPath("FlowerImages") + "/new.jpg");
        imgNew.Visible = true;
        imgNew.ImageUrl = @"~\FlowerImages\new.jpg";
    }
}