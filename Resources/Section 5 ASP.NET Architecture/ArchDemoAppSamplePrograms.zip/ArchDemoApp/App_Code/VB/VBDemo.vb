﻿Imports Microsoft.VisualBasic

Public Class VBDemo
    Public Function SayHello(ByVal name As String) As String
        Return "Hello " & name
    End Function
End Class
