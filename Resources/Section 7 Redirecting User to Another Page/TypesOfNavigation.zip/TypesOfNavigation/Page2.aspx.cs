﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Page2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (PreviousPage == null)
        {
            //Response.Redirect or Hyperlink is used to come to this page...
            string demo = Request.QueryString["demo"];
            if (demo != null)
                lblDemo.Text = "REDIRECT: " + demo;

        }
        else if (PreviousPage.IsCrossPagePostBack)
        {
            //Crosspage Postback has been used on Page1
            TextBox txt = (TextBox) PreviousPage.FindControl("txtDemo");
            lblDemo.Text = "CROSSPAGEPOSTBACK: " + txt.Text;
            //OR
            //<%@ PreviousPageType VirtualPath="~/Page1.aspx" %> in Page2.aspx
            lblDemo.Text =  "CROSSPAGEPOSTBACK: " + PreviousPage.DemoText;
        }
        else
        {
            //Server.Transfer has been used on Page1
            lblDemo.Text = "Transfer: " + Context.Items["demo"].ToString();
        }
    }
}
