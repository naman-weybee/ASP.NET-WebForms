﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Account : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void imgCalendar_Click(object sender, ImageClickEventArgs e)
    {
        ccDate.Visible = true;
    }
    protected void rbnSchedule_CheckedChanged(object sender, EventArgs e)
    {
        lblDateTransfer.Visible = true;
        txtDate.Visible = true;
        imgCalendar.Visible = true;
    }
    protected void rbnTransfer_CheckedChanged(object sender, EventArgs e)
    {
        lblDateTransfer.Visible = false;
        txtDate.Visible = false;
        imgCalendar.Visible = false;
        ccDate.Visible = false;
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect(Request.RawUrl);
    }
    protected void ccDate_SelectionChanged(object sender, EventArgs e)
    {
        txtDate.Text = ccDate.SelectedDate.ToShortDateString();
    }
}