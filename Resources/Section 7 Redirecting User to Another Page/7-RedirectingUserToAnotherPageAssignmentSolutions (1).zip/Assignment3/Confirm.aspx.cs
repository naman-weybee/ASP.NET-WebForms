﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Confirm : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (PreviousPage.IsCrossPagePostBack)
            {
                DropDownList ddlBeneficiary = (DropDownList)PreviousPage.FindControl("ddlBeneficiary");
                lblBenefName.Text = ddlBeneficiary.SelectedValue;
                TextBox txtAmount = (TextBox)PreviousPage.FindControl("txtAmount");
                lblAmount.Text = txtAmount.Text;
                RadioButton rbntransfer = (RadioButton)PreviousPage.FindControl("rbnTransfer");
                RadioButton rbnSchedule = (RadioButton)PreviousPage.FindControl("rbnSchedule");
                if (rbnSchedule.Checked == true)
                {
                    TextBox txtDate = (TextBox)PreviousPage.FindControl("txtDate");
                    lblDate.Text = "Scheduled date: " + txtDate.Text;
                }
            }
        }
    }
    protected void btnConfirm_Click(object sender, EventArgs e)
    {
        lblMsg.Text = "Successfully transferred the amount.";
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Account.aspx");
    }
}