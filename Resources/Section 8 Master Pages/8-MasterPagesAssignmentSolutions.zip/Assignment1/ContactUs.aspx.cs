﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ContactUs : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        Label lbl = (Label)Master.FindControl("lblMsgMastr");
        if (txtName.Text != "" && txtContactNum.Text != "" && txtEmailId.Text != "" && txtComment.Text != "")
        {
            lbl.Text = "Your enquiry is posted successfully. We will get back to you soon.";
            lbl.ForeColor = System.Drawing.Color.Navy;
        }
        else
        {
            lbl.Text = "Please provide the details.";
            lbl.ForeColor = System.Drawing.Color.White;
        }
    }
}